fetch("http://127.0.0.1:8000/po/")
.then(res => res.json())
.then(data => {
    let tbody = document.querySelector("#poTable tbody");
    data.forEach(po => {
        tbody.innerHTML += `<tr>
            <td>${po.id}</td>
            <td>${po.reference_no}</td>
            <td>${po.total_amount}</td>
            <td>${po.status}</td>
        </tr>`;
    });
});
