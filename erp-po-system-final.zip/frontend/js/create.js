async function loadData(){
let v = await fetch("http://127.0.0.1:8000/vendors/").then(r=>r.json());
let p = await fetch("http://127.0.0.1:8000/products/").then(r=>r.json());

v.forEach(x=>{
document.getElementById("vendor").innerHTML += `<option value="${x.id}">${x.name}</option>`;
});

window.products = p;
}
loadData();

function addRow(){
let row = document.getElementById("productTable").insertRow();
row.innerHTML = `
<td><select class="form-control product">${products.map(p=>`<option value="${p.id}">${p.name}</option>`)}</select></td>
<td><input class="form-control qty" type="number"/></td>
<td><input class="form-control price" type="number"/></td>
<td><button onclick="ai(this)">AI</button></td>`;
}

function ai(btn){
let name = btn.parentElement.parentElement.querySelector(".product").selectedOptions[0].text;
fetch("http://127.0.0.1:8000/ai/description",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})})
.then(r=>r.json()).then(d=>alert(d.description));
}

function submitPO(){
let items=[];
document.querySelectorAll("#productTable tr").forEach((r,i)=>{
if(i==0)return;
items.push({
product_id:r.querySelector(".product").value,
quantity:r.querySelector(".qty").value,
price:r.querySelector(".price").value
});
});

fetch("http://127.0.0.1:8000/po/",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({reference_no:"PO"+Date.now(),vendor_id:document.getElementById("vendor").value,items})
});
}
