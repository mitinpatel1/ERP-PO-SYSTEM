# ERP PO System (Final)

## Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

## Frontend
Open frontend/index.html

## PostgreSQL
Set env:
DATABASE_URL=postgresql+psycopg2://user:password@localhost:5432/erp
