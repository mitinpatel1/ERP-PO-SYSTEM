from fastapi import APIRouter

router = APIRouter()

@router.post("/description")
def ai_desc(data: dict):
    name = data.get("name", "Product")
    return {"description": f"{name} is a high-quality product designed for modern needs. It delivers reliability and performance."}
