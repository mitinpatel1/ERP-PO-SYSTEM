from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.deps import get_db
from app.models.models import Vendor

router = APIRouter()

@router.get("/")
def get_vendors(db: Session = Depends(get_db)):
    return db.query(Vendor).all()

@router.post("/")
def create_vendor(data: dict, db: Session = Depends(get_db)):
    v = Vendor(**data)
    db.add(v)
    db.commit()
    db.refresh(v)
    return v
