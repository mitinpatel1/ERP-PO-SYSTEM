from fastapi import APIRouter
from jose import jwt
from datetime import datetime, timedelta

router = APIRouter()
SECRET = "secret"

@router.post("/login")
def login():
    payload = {"user": "demo", "exp": datetime.utcnow() + timedelta(hours=1)}
    token = jwt.encode(payload, SECRET, algorithm="HS256")
    return {"access_token": token}
