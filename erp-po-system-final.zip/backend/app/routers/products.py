from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.deps import get_db
from app.models.models import Product

router = APIRouter()

@router.get("/")
def get_products(db: Session = Depends(get_db)):
    return db.query(Product).all()

@router.post("/")
def create_product(data: dict, db: Session = Depends(get_db)):
    p = Product(**data)
    db.add(p)
    db.commit()
    db.refresh(p)
    return p
