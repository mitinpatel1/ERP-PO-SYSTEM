from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.deps import get_db
from app.models.models import PurchaseOrder, POItem

router = APIRouter()

def calculate_total(items):
    subtotal = sum([i["price"] * i["quantity"] for i in items])
    return float(subtotal + subtotal * 0.05)

@router.get("/")
def list_po(db: Session = Depends(get_db)):
    return db.query(PurchaseOrder).all()

@router.post("/")
def create_po(data: dict, db: Session = Depends(get_db)):
    total = calculate_total(data["items"])
    po = PurchaseOrder(
        reference_no=data["reference_no"],
        vendor_id=data["vendor_id"],
        total_amount=total,
        status="CREATED"
    )
    db.add(po)
    db.commit()
    db.refresh(po)

    for item in data["items"]:
        db.add(POItem(po_id=po.id, product_id=item["product_id"], quantity=item["quantity"], price=item["price"]))
    db.commit()

    return {"message": "PO Created", "total": total}
