from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import vendors, products, po, auth, ai
from app.core.database import Base, engine

app = FastAPI(title="ERP PO System")

# Create tables
Base.metadata.create_all(bind=engine)

# CORS (allow local frontend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(vendors.router, prefix="/vendors", tags=["Vendors"])
app.include_router(products.router, prefix="/products", tags=["Products"])
app.include_router(po.router, prefix="/po", tags=["Purchase Orders"])
app.include_router(ai.router, prefix="/ai", tags=["AI"])

@app.get("/")
def root():
    return {"message": "ERP PO System Running"}
